package ar.edu.nuevohogar.ui;

import ar.edu.nuevohogar.dao.Database;
import ar.edu.nuevohogar.model.Row;
import ar.edu.nuevohogar.service.*;

import javafx.application.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.*;

import java.math.BigDecimal;
import java.nio.file.*;
import java.nio.file.Path;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.*;

/** Presentación JavaFX: catálogo y paneles por rol sobre los mismos servicios. */
public final class AgencyApp extends Application {
    private AgencyService service;
    private Stage stage;
    private final BorderPane root = new BorderPane();
    private VBox content;
    private String activePage = "Catálogo";

    @Override
    public void start(Stage stage) {
        this.stage = stage;
        stage.setTitle("Nuevo Hogar · Gestión inmobiliaria");
        Scene scene = new Scene(root, 1320, 860);
        scene.getStylesheets()
                .add(Objects.requireNonNull(getClass().getResource("/theme.css")).toExternalForm());
        stage.setScene(scene);
        stage.setMinWidth(1000);
        stage.setMinHeight(700);
        root.setCenter(new Label("Preparando Nuevo Hogar…"));
        stage.show();
        javafx.concurrent.Task<AgencyService> init =
                new javafx.concurrent.Task<>() {
                    protected AgencyService call() throws Exception {
                        Database db = new Database();
                        db.initialize();
                        DemoData.seed(db);
                        return new AgencyService(db);
                    }
                };
        init.setOnSucceeded(
                e -> {
                    service = init.getValue();
                    shell();
                    if (service.needsAdmin()) bootstrap();
                    else catalog();
                });
        init.setOnFailed(
                e -> {
                    VBox box =
                            new VBox(
                                    18,
                                    title("No pudimos abrir la base de datos"),
                                    label(
                                            "Revisá config.properties y que hayas aplicado los dos"
                                                    + " scripts SQL.",
                                            "subtitle"),
                                    button("Reintentar", () -> start(stage)));
                    box.getStyleClass().add("page");
                    root.setCenter(box);
                    error(init.getException());
                });
        Thread t = new Thread(init, "inicio-base-datos");
        t.setDaemon(true);
        t.start();
    }

    private void shell() {
        HBox header = new HBox(20);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("topbar");
        VBox brand =
                new VBox(
                        0,
                        label("⌂  Nuevo Hogar", "brand"),
                        label("Tu próximo hogar, está aquí", "footer"));
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        header.getChildren().addAll(brand, gap, button("Catálogo", this::catalog));
        if (service.signedIn()) {
            header.getChildren()
                    .addAll(
                            button("Mi perfil", this::profile),
                            label(
                                    service.current().text("nombre") + " · " + roleName(),
                                    "subtitle"),
                            secondary(
                                    "Cerrar sesión",
                                    () -> {
                                        service.logout();
                                        shell();
                                        catalog();
                                    }));
        } else
            header.getChildren()
                    .addAll(
                            secondary("Iniciar sesión", this::login),
                            button("Registrarme", this::register));
        root.setTop(header);
        if (!service.signedIn()) {
            root.setLeft(null);
            return;
        }
        VBox nav = new VBox(8);
        nav.setPrefWidth(218);
        nav.getStyleClass().add("sidebar");
        nav.getChildren()
                .addAll(
                        label("ESPACIO " + roleName().toUpperCase(Locale.ROOT), "footer"),
                        button("Inicio", this::dashboard),
                        button("Propiedades", this::propertyList),
                        button("Solicitudes de carga", this::requests));
        if (service.role() != 3)
            nav.getChildren()
                    .addAll(
                            button("Clientes", this::clients),
                            button("Propietarios y convenios", this::agreements),
                            button("Edificios y unidades", this::buildings),
                            button("Ventas y alquileres", this::operations),
                            button("Reportes", this::reports));
        else
            nav.getChildren()
                    .addAll(
                            button(
                                    "Mis intereses",
                                    () -> interests(service.current().id("id_usuario"))),
                            button(
                                    "Mi búsqueda",
                                    () -> preferences(service.current().id("id_usuario"))));
        if (service.role() == 1) nav.getChildren().add(button("Usuarios", this::users));
        nav.getChildren()
                .addAll(
                        button("Notificaciones", this::notifications),
                        button("Configuración", this::settings));
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        nav.getChildren()
                .addAll(
                        spacer,
                        house(170, 105, 1),
                        label(
                                "Grandes oportunidades\ncomienzan con una\nbuena gestión.",
                                "footer"));
        ScrollPane navScroll = new ScrollPane(nav);
        navScroll.setFitToWidth(true);
        navScroll.setPrefWidth(218);
        navScroll.setStyle("-fx-background-color: #244f65;");
        root.setLeft(navScroll);
    }

    private String roleName() {
        return switch (service.role()) {
            case 1 -> "Administrador";
            case 2 -> "Agente";
            case 3 -> "Cliente";
            default -> "Invitado";
        };
    }

    private static Label label(String text, String style) {
        Label l = new Label(text);
        l.getStyleClass().add(style);
        l.setWrapText(true);
        return l;
    }

    private static Label title(String text) {
        return label(text, "page-title");
    }

    private Button button(String text, Runnable action) {
        Button b = new Button(text);
        b.setOnAction(e -> safe(action));
        return b;
    }

    private Button secondary(String text, Runnable action) {
        Button b = button(text, action);
        b.getStyleClass().add("secondary");
        return b;
    }

    private void safe(Runnable action) {
        try {
            action.run();
        } catch (Exception e) {
            error(e);
        }
    }

    private void error(Throwable e) {
        e.printStackTrace();
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.initOwner(stage);
        a.setTitle("Revisá los datos");
        a.setHeaderText("No se completó la acción");
        a.setContentText(
                e.getMessage() == null
                        ? "Ocurrió un error. Revisá la consola para más detalle."
                        : e.getMessage());
        a.showAndWait();
    }

    private void info(String message) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
        a.initOwner(stage);
        a.setHeaderText(null);
        a.showAndWait();
    }

    private void page(String title, String subtitle) {
        activePage = title;
        content = new VBox(22);
        content.getStyleClass().add("page");
        content.getChildren().add(new VBox(7, title(title), label(subtitle, "subtitle")));
        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        root.setCenter(scroll);
    }

    private static VBox card(Node... nodes) {
        VBox v = new VBox(13, nodes);
        v.getStyleClass().add("card");
        return v;
    }

    private static HBox row(Node... nodes) {
        HBox h = new HBox(12, nodes);
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    private static FlowPane flow(Node... nodes) {
        FlowPane f = new FlowPane(12, 12, nodes);
        return f;
    }

    private void dialog(String title, Node body, String action, Runnable save) {
        Dialog<Void> d = new Dialog<>();
        d.initOwner(stage);
        d.setTitle(title);
        d.setResizable(true);
        ScrollPane scroll = new ScrollPane(body);
        scroll.setFitToWidth(true);
        scroll.setPrefViewportWidth(730);
        scroll.setPrefViewportHeight(Math.min(620, stage.getHeight() - 200));
        d.getDialogPane().setContent(scroll);
        d.getDialogPane()
                .getStylesheets()
                .add(getClass().getResource("/theme.css").toExternalForm());
        ButtonType ok = new ButtonType(action, ButtonBar.ButtonData.OK_DONE);
        d.getDialogPane().getButtonTypes().addAll(ok, ButtonType.CANCEL);
        d.getDialogPane()
                .lookupButton(ok)
                .addEventFilter(
                        javafx.event.ActionEvent.ACTION,
                        e -> {
                            e.consume();
                            try {
                                save.run();
                                d.close();
                            } catch (Exception ex) {
                                error(ex);
                            }
                        });
        d.showAndWait();
    }

    private static Pane house(double width, double height, int variant) {
        Pane p = new Pane();
        p.setPrefSize(width, height);
        p.setMinSize(width, height);
        p.setMaxSize(width, height);
        Rectangle sky =
                new Rectangle(width, height, Color.web(variant % 2 == 0 ? "#dae5df" : "#dfe6e4"));
        sky.setArcHeight(10);
        sky.setArcWidth(10);
        Rectangle lawn = new Rectangle(0, height * .77, width, height * .23);
        lawn.setFill(Color.web("#9bb9a0"));
        Rectangle wall = new Rectangle(width * .18, height * .34, width * .60, height * .48);
        wall.setFill(Color.web("#fbf4df"));
        Polygon roof =
                new Polygon(
                        width * .12,
                        height * .37,
                        width * .49,
                        height * .08,
                        width * .85,
                        height * .37);
        roof.setFill(Color.web("#426879"));
        Rectangle door = new Rectangle(width * .44, height * .54, width * .12, height * .28);
        door.setFill(Color.web("#ba9166"));
        p.getChildren().addAll(sky, lawn, wall, roof, door);
        for (double x : new double[] {.25, .62}) {
            Rectangle window = new Rectangle(width * x, height * .47, width * .10, height * .14);
            window.setFill(Color.web("#8fbbc5"));
            p.getChildren().add(window);
        }
        Circle tree = new Circle(width * .9, height * .48, height * .16, Color.web("#729987"));
        p.getChildren().add(tree);
        p.setAccessibleText("Ilustración de una vivienda; no es una fotografía del inmueble");
        return p;
    }

    private TableView<Row> table(List<Row> rows, String... cols) {
        TableView<Row> t = new TableView<>(FXCollections.observableArrayList(rows));
        t.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        for (int i = 0; i < cols.length; i += 2) {
            String key = cols[i];
            TableColumn<Row, String> c = new TableColumn<>(cols[i + 1]);
            c.setCellValueFactory(v -> new SimpleStringProperty(v.getValue().text(key)));
            t.getColumns().add(c);
        }
        t.setPrefHeight(Math.max(140, Math.min(410, rows.size() * 40 + 48)));
        t.setPlaceholder(new Label("Todavía no hay registros para mostrar."));
        return t;
    }

    private Row selected(TableView<Row> t) {
        Row r = t.getSelectionModel().getSelectedItem();
        if (r == null) throw new IllegalArgumentException("Seleccioná una fila de la tabla.");
        return r;
    }

    private static int number(String text) {
        return text == null || text.isBlank() ? 0 : Integer.parseInt(text);
    }

    private static BigDecimal money(String text) {
        return new BigDecimal(text.trim().replace(',', '.'));
    }

    private void bootstrap() {
        page(
                "Bienvenido a Nuevo Hogar",
                "Creá el administrador inicial de esta base. No hay contraseñas predeterminadas en"
                        + " MySQL.");
        Form f = userForm();
        PasswordField password = f.password("password", "Contraseña (mínimo 10 caracteres)");
        content.getChildren()
                .add(
                        card(
                                f,
                                button(
                                        "Crear administrador",
                                        () -> {
                                            service.bootstrapAdmin(f.values(), password.getText());
                                            service.login(f.value("email"), password.getText());
                                            shell();
                                            dashboard();
                                        })));
    }

    private Form userForm() {
        Form f = new Form();
        f.text("nombre", "Nombre *", "");
        f.text("apellido", "Apellido *", "");
        f.choice("tipo_documento", "Tipo de documento", "DNI", "DNI", "Pasaporte", "Otro");
        f.text("dni", "Número de documento *", "");
        f.text("email", "Correo electrónico *", "");
        f.text("telefono", "Teléfono", "");
        return f;
    }

    private void login() {
        page(
                "Bienvenido/a a Nuevo Hogar",
                "Ingresá para administrar tus propiedades y continuar tus gestiones.");
        Form f = new Form(1);
        f.text("email", "Correo electrónico", "");
        PasswordField pass = f.password("password", "Contraseña");
        VBox left =
                card(
                        house(340, 215, 0),
                        title("Tu próximo hogar\nempieza acá."),
                        label(
                                "Encontrá propiedades, seguí tus solicitudes y mantené toda tu"
                                        + " información en un solo lugar.",
                                "subtitle"));
        HBox.setHgrow(left, Priority.ALWAYS);
        VBox right =
                card(
                        label("Iniciar sesión", "section-title"),
                        f,
                        button(
                                "Iniciar sesión",
                                () -> {
                                    service.login(f.value("email"), pass.getText());
                                    shell();
                                    dashboard();
                                }),
                        secondary("Crear una cuenta", this::register));
        HBox.setHgrow(right, Priority.ALWAYS);
        content.getChildren().add(row(left, right));
        if (service.db.demo)
            content.getChildren()
                    .add(
                            card(
                                    label("MODO DEMOSTRACIÓN · datos ficticios", "section-title"),
                                    label(
                                            "Administrador: admin@nuevohogar.demo\n"
                                                    + "Agente: agente@nuevohogar.demo\n"
                                                    + "Cliente: cliente@nuevohogar.demo\n"
                                                    + "Contraseña para los tres: "
                                                    + DemoData.PASSWORD,
                                            "subtitle")));
    }

    private void register() {
        page(
                "Crear cuenta",
                "Completá tus datos para buscar, consultar y solicitar publicaciones.");
        Form personal = new Form();
        personal.text("nombre", "Nombre *", "");
        personal.text("apellido", "Apellido *", "");
        personal.choice("tipo_documento", "Tipo de documento", "DNI", "DNI", "Pasaporte", "Otro");
        personal.text("dni", "Número de documento *", "");
        personal.date("fecha_nacimiento", "Fecha de nacimiento", "");
        personal.choice(
                "genero",
                "Género (opcional)",
                "Prefiero no indicar",
                "Prefiero no indicar",
                "Femenino",
                "Masculino",
                "Otro");
        Form contact = new Form();
        contact.text("email", "Correo electrónico *", "");
        contact.text("telefono", "Teléfono", "");
        PasswordField pass = contact.password("password", "Contraseña * (10 caracteres o más)");
        PasswordField confirm = contact.password("confirm", "Confirmar contraseña *");
        Form address = new Form();
        address.text("direccion", "Dirección", "");
        address.text("localidad", "Localidad", "");
        Form[] steps = {personal, contact, address};
        String[] names = {
            "1  Datos personales", "2  Datos de contacto", "3  Dirección", "4  Finalizar"
        };
        int[] index = {0};
        VBox area = card();
        VBox nav = new VBox(16);
        nav.setMinWidth(210);
        for (String name : names) nav.getChildren().add(label(name, "section-title"));
        Runnable[] show = {null};
        show[0] =
                () -> {
                    area.getChildren()
                            .setAll(
                                    label(
                                            "Crear cuenta · Paso " + (index[0] + 1) + " de 4",
                                            "section-title"),
                                    steps[index[0]]);
                    HBox controls = row();
                    if (index[0] > 0)
                        controls.getChildren()
                                .add(
                                        secondary(
                                                "Volver",
                                                () -> {
                                                    index[0]--;
                                                    show[0].run();
                                                }));
                    controls.getChildren()
                            .add(
                                    button(
                                            index[0] == 2 ? "Crear cuenta" : "Siguiente",
                                            () -> {
                                                if (index[0] == 0) {
                                                    for (String k :
                                                            List.of("nombre", "apellido", "dni"))
                                                        if (personal.value(k).isBlank())
                                                            throw new IllegalArgumentException(
                                                                    "Completá tus datos"
                                                                            + " personales.");
                                                }
                                                if (index[0] == 1) {
                                                    if (contact.value("email").isBlank()
                                                            || pass.getText().length() < 10
                                                            || !pass.getText()
                                                                    .equals(confirm.getText()))
                                                        throw new IllegalArgumentException(
                                                                "Revisá el correo y las"
                                                                    + " contraseñas; deben"
                                                                    + " coincidir y tener al menos"
                                                                    + " 10 caracteres.");
                                                }
                                                if (index[0] < 2) {
                                                    index[0]++;
                                                    show[0].run();
                                                } else {
                                                    Map<String, String> d =
                                                            new HashMap<>(personal.values());
                                                    d.putAll(contact.values());
                                                    d.putAll(address.values());
                                                    service.register(d, pass.getText());
                                                    service.login(d.get("email"), pass.getText());
                                                    shell();
                                                    page(
                                                            "¡Registro completado!",
                                                            "Tu cuenta se creó correctamente. Ya"
                                                                    + " podés buscar propiedades y"
                                                                    + " enviar solicitudes.");
                                                    content.getChildren()
                                                            .add(
                                                                    card(
                                                                            button(
                                                                                    "Ir al"
                                                                                        + " catálogo",
                                                                                    this::catalog),
                                                                            secondary(
                                                                                    "Ver mi perfil",
                                                                                    this
                                                                                            ::profile)));
                                                }
                                            }));
                    area.getChildren().add(controls);
                };
        show[0].run();
        HBox.setHgrow(area, Priority.ALWAYS);
        content.getChildren().add(row(nav, area));
    }

    private void catalog() {
        page(
                "Encontrá la propiedad que estás buscando",
                "Casas, departamentos y terrenos. Un lugar para cada nueva etapa.");
        HBox hero =
                row(
                        new VBox(
                                12,
                                title("El próximo capítulo\nde tu vida."),
                                label(
                                        "Explorá las propiedades aprobadas por nuestro equipo.",
                                        "subtitle")),
                        house(220, 130, 0));
        hero.getStyleClass().add("hero");
        content.getChildren().add(hero);
        Form filter = new Form(4);
        filter.text("q", "Buscar por título, dirección o localidad", "");
        filter.rows("type", "Tipo de propiedad", service.lookup("tipos_propiedad"), 0, true);
        filter.rows("operation", "Operación", service.lookup("tipos_transaccion"), 0, true);
        filter.text("max", "Precio máximo (opcional)", "");
        filter.choice("currency", "Moneda del precio máximo", "USD", "USD", "ARS");
        filter.text("beds", "Dormitorios mínimos", "0");
        filter.text("capacity", "Capacidad mínima", "0");
        Map<Integer, CheckBox> features = featureChecks(Set.of());
        FlowPane cards = new FlowPane(18, 18);
        Label count = label("", "subtitle");
        Runnable search =
                () -> {
                    BigDecimal max =
                            filter.value("max").isBlank() ? null : money(filter.value("max"));
                    if (max != null && max.signum() < 0)
                        throw new IllegalArgumentException(
                                "El precio máximo no puede ser negativo.");
                    int type = number(filter.value("type")),
                            operation = number(filter.value("operation"));
                    int beds = number(filter.value("beds")),
                            capacity = number(filter.value("capacity"));
                    if (beds < 0 || capacity < 0)
                        throw new IllegalArgumentException(
                                "Los filtros numéricos no pueden ser negativos.");
                    List<Row> rows =
                            service.properties(
                                    true,
                                    filter.value("q"),
                                    type == 0 ? null : type,
                                    operation == 0 ? null : operation,
                                    max,
                                    filter.value("currency"),
                                    beds,
                                    capacity,
                                    checked(features));
                    cards.getChildren().clear();
                    count.setText(rows.size() + " propiedades encontradas");
                    for (Row p : rows) cards.getChildren().add(propertyCard(p));
                    if (rows.isEmpty())
                        cards.getChildren()
                                .add(
                                        card(
                                                label(
                                                        "No encontramos coincidencias",
                                                        "section-title"),
                                                label(
                                                        "Probá con otra localidad o ampliá los"
                                                                + " filtros.",
                                                        "subtitle")));
                };
        TitledPane advanced =
                new TitledPane("Características", flow(features.values().toArray(Node[]::new)));
        advanced.setExpanded(false);
        content.getChildren()
                .addAll(card(filter, advanced, button("Buscar propiedades", search)), count, cards);
        search.run();
    }

    private Map<Integer, CheckBox> featureChecks(Set<Integer> selected) {
        Map<Integer, CheckBox> map = new LinkedHashMap<>();
        for (Row r : service.lookup("caracteristicas")) {
            CheckBox c = new CheckBox(r.text("etiqueta"));
            c.setSelected(selected.contains(r.id("id")));
            map.put(r.id("id"), c);
        }
        return map;
    }

    private static Set<Integer> checked(Map<Integer, CheckBox> map) {
        Set<Integer> s = new HashSet<>();
        map.forEach(
                (id, c) -> {
                    if (c.isSelected()) s.add(id);
                });
        return s;
    }

    private Node propertyVisual(Row p, double width, double height) {
        for (Row a : service.attachments(p.id("id_propiedad"), false))
            if (a.text("tipo").equals("Imagen")) {
                Path file = service.attachmentPath(p.id("id_propiedad"), a.id("id"), false);
                if (Files.exists(file)) {
                    Image image = new Image(file.toUri().toString(), width, height, true, true);
                    if (!image.isError()) {
                        ImageView v = new ImageView(image);
                        v.setFitWidth(width);
                        v.setFitHeight(height);
                        v.setPreserveRatio(true);
                        return v;
                    }
                }
            }
        return house(width, height, p.id("id_propiedad"));
    }

    private VBox propertyCard(Row p) {
        int id = p.id("id_propiedad");
        VBox v = new VBox(12);
        v.getStyleClass().add("property-card");
        v.setPrefWidth(255);
        v.setMaxWidth(255);
        VBox text =
                new VBox(
                        9,
                        label(p.text("tipo") + " · " + p.text("comercial"), "badge"),
                        label(p.text("titulo"), "section-title"),
                        label(p.text("localidad"), "subtitle"),
                        label(
                                p.text("dormitorios")
                                        + " dormitorios   ·   "
                                        + p.text("superficie_total_m2")
                                        + " m²",
                                "footer"));
        text.setPadding(new Insets(0, 15, 0, 15));
        for (Row o : service.offers(id))
            text.getChildren()
                    .add(
                            label(
                                    o.text("operacion")
                                            + " · "
                                            + o.text("moneda")
                                            + " "
                                            + o.text("precio"),
                                    "price"));
        Button details = button("Ver propiedad", () -> propertyDetails(id));
        details.setMaxWidth(Double.MAX_VALUE);
        text.getChildren().add(details);
        v.getChildren().addAll(propertyVisual(p, 253, 155), text);
        return v;
    }

    private void propertyDetails(int id) {
        Row p = service.property(id);
        page(p.text("titulo"), p.text("direccion") + " · " + p.text("localidad"));
        VBox facts = card(label(p.text("tipo") + " · " + p.text("comercial"), "badge"));
        for (Row o : service.offers(id))
            facts.getChildren()
                    .add(
                            label(
                                    o.text("operacion")
                                            + " · "
                                            + o.text("moneda")
                                            + " "
                                            + o.text("precio"),
                                    "price"));
        facts.getChildren()
                .addAll(
                        label(
                                p.text("ambientes")
                                        + " ambientes · "
                                        + p.text("dormitorios")
                                        + " dormitorios · "
                                        + p.text("banos")
                                        + " baños\n"
                                        + p.text("superficie_total_m2")
                                        + " m² totales · "
                                        + p.text("superficie_cubierta_m2")
                                        + " m² cubiertos\nAntigüedad: "
                                        + p.text("antiguedad_anos")
                                        + " años · Capacidad: "
                                        + p.text("capacidad")
                                        + " personas\nExpensas: "
                                        + p.text("expensas"),
                                "subtitle"),
                        button(
                                "Contactar / Me interesa",
                                () -> {
                                    if (!service.signedIn()) {
                                        login();
                                        return;
                                    }
                                    if (service.role() != 3) {
                                        info(
                                                "Podés vincular un cliente desde Clientes →"
                                                        + " Intereses.");
                                        return;
                                    }
                                    Form f = new Form();
                                    f.area(
                                            "message",
                                            "Consulta",
                                            "Me interesa recibir información sobre esta"
                                                    + " propiedad.");
                                    dialog(
                                            "Contactar a la inmobiliaria",
                                            f,
                                            "Enviar consulta",
                                            () -> {
                                                service.interest(
                                                        service.current().id("id_usuario"),
                                                        id,
                                                        "Interesado",
                                                        f.value("message"));
                                                info(
                                                        "Consulta registrada en tu ficha de"
                                                                + " intereses.");
                                            });
                                }));
        HBox.setHgrow(facts, Priority.ALWAYS);
        content.getChildren().add(row(propertyVisual(p, 460, 280), facts));
        content.getChildren()
                .add(
                        card(
                                label("Descripción", "section-title"),
                                label(p.text("descripcion"), "subtitle"),
                                label(
                                        "Características: "
                                                + String.join(
                                                        " · ",
                                                        service.features(id).stream()
                                                                .map(r -> r.text("etiqueta"))
                                                                .toList()),
                                        "subtitle")));
        if (p.id("id_edificio") > 0)
            content.getChildren()
                    .add(
                            card(
                                    label(
                                            "Edificio #"
                                                    + p.id("id_edificio")
                                                    + " · Unidad "
                                                    + p.text("numero_unidad"),
                                            "section-title")));
        VBox files = card(label("Fotografías y videos", "section-title"));
        addFileButtons(files, id, false);
        content.getChildren().add(files);
        if (service.signedIn()
                && (service.role() != 3
                        || p.id("id_propietario") == service.current().id("id_usuario"))) {
            VBox docs = card(label("Documentación privada", "section-title"));
            addFileButtons(docs, id, true);
            content.getChildren()
                    .addAll(
                            docs,
                            row(
                                    button("Editar ficha", () -> propertyForm(p)),
                                    secondary("Adjuntar archivos", () -> upload(id))));
            if (service.role() != 3)
                content.getChildren()
                        .add(
                                table(
                                        service.stateHistory(id),
                                        "fecha",
                                        "Fecha",
                                        "estado",
                                        "Estado",
                                        "motivo",
                                        "Motivo"));
        }
    }

    private void addFileButtons(VBox box, int id, boolean docs) {
        List<Row> files = service.attachments(id, docs);
        if (files.isEmpty())
            box.getChildren().add(label("Todavía no se cargaron archivos.", "subtitle"));
        for (Row f : files)
            box.getChildren()
                    .add(
                            secondary(
                                    f.text("tipo")
                                            + " · "
                                            + (docs ? f.text("nombre") : "Archivo #" + f.id("id")),
                                    () -> {
                                        Path path = service.attachmentPath(id, f.id("id"), docs);
                                        if (!Files.isRegularFile(path))
                                            throw new IllegalArgumentException(
                                                    "El archivo no está en la carpeta compartida"
                                                            + " configurada.");
                                        getHostServices().showDocument(path.toUri().toString());
                                    }));
    }

    private void upload(int id) {
        Form f = new Form();
        f.choice(
                "tipo",
                "Tipo de archivo",
                "Imagen",
                "Imagen",
                "Video",
                "Plano",
                "Escritura",
                "Servicio",
                "Impuesto");
        Label filename = label("Ningún archivo seleccionado · Máximo 50 MB", "subtitle");
        Path[] path = {null};
        VBox box =
                card(
                        label("La propiedad debe estar en borrador o rechazada.", "subtitle"),
                        f,
                        filename,
                        secondary(
                                "Seleccionar archivo",
                                () -> {
                                    FileChooser fc = new FileChooser();
                                    fc.setTitle("Adjuntar documentación o multimedia");
                                    java.io.File file = fc.showOpenDialog(stage);
                                    if (file != null) {
                                        path[0] = file.toPath();
                                        filename.setText(file.getName());
                                    }
                                }));
        dialog(
                "Adjuntar archivo",
                box,
                "Guardar archivo",
                () -> {
                    if (path[0] == null)
                        throw new IllegalArgumentException("Seleccioná un archivo.");
                    try {
                        service.attach(id, path[0], f.value("tipo"));
                        propertyDetails(id);
                    } catch (Exception e) {
                        throw new IllegalArgumentException(e.getMessage(), e);
                    }
                });
    }

    private void dashboard() {
        List<Row> properties = service.allProperties();
        List<Row> requests = service.requests();
        page(
                "¡Hola, " + service.current().text("nombre") + "!",
                "Aquí tenés un resumen de "
                        + (service.role() == 3
                                ? "tus gestiones"
                                : "la actividad de la inmobiliaria")
                        + " · "
                        + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        FlowPane metrics = new FlowPane(16, 16);
        metrics.getChildren()
                .addAll(
                        stat("Propiedades", properties.size()),
                        stat(
                                "Publicadas",
                                properties.stream()
                                        .filter(r -> r.id("id_estado_verificacion") == 3)
                                        .filter(
                                                r ->
                                                        Set.of(1, 2)
                                                                .contains(
                                                                        r.id(
                                                                                "id_estado_comercial")))
                                        .count()),
                        stat(
                                "En revisión",
                                requests.stream()
                                        .filter(r -> r.text("estado").equals("Pendiente"))
                                        .count()),
                        stat(
                                "Rechazadas",
                                properties.stream()
                                        .filter(r -> r.id("id_estado_verificacion") == 4)
                                        .count()));
        content.getChildren().add(metrics);
        PieChart pie = new PieChart();
        Map<String, Long> counts = new LinkedHashMap<>();
        properties.forEach(p -> counts.merge(p.text("verificacion"), 1L, Long::sum));
        counts.forEach((k, v) -> pie.getData().add(new PieChart.Data(k + " (" + v + ")", v)));
        pie.setPrefSize(330, 260);
        pie.setLabelsVisible(false);
        pie.setTitle("Estado de las propiedades");
        TableView<Row> t =
                table(
                        properties.stream().limit(6).toList(),
                        "id_propiedad",
                        "ID",
                        "titulo",
                        "Propiedad",
                        "localidad",
                        "Ubicación",
                        "verificacion",
                        "Publicación");
        t.setPrefWidth(580);
        VBox summary =
                card(
                        label(
                                service.role() == 3 ? "Mis propiedades" : "Cartera de propiedades",
                                "section-title"),
                        t,
                        row(
                                button(
                                        "Ver propiedad",
                                        () -> propertyDetails(selected(t).id("id_propiedad"))),
                                secondary("Ver todas", this::propertyList)));
        HBox.setHgrow(summary, Priority.ALWAYS);
        content.getChildren().add(row(summary, card(pie)));
        TableView<Row> rq =
                table(
                        requests.stream().limit(5).toList(),
                        "id_publicacion",
                        "ID",
                        "titulo",
                        "Propiedad",
                        "estado",
                        "Estado",
                        "fecha_solicitud",
                        "Fecha");
        content.getChildren()
                .add(
                        card(
                                label("Últimas solicitudes", "section-title"),
                                rq,
                                secondary("Gestionar solicitudes", this::requests)));
        if (service.role() != 3) {
            List<Row> activity = service.activity().stream().limit(5).toList();
            content.getChildren()
                    .add(
                            card(
                                    label("Actividad reciente del equipo", "section-title"),
                                    table(
                                            activity, "fecha", "Fecha", "usuario", "Usuario",
                                            "accion", "Acción", "detalle", "Detalle")));
        }
    }

    private static VBox stat(String name, long value) {
        VBox v = card(label(name, "subtitle"), label("" + value, "stat"));
        v.setPrefWidth(203);
        return v;
    }

    private void propertyList() {
        page(
                service.role() == 3 ? "Mis propiedades" : "Propiedades",
                "Administrá las fichas, sus estados y las solicitudes de publicación.");
        List<Row> all = service.allProperties();
        TableView<Row> t =
                table(
                        all,
                        "id_propiedad",
                        "ID",
                        "titulo",
                        "Título",
                        "localidad",
                        "Localidad",
                        "propietario",
                        "Propietario",
                        "verificacion",
                        "Publicación",
                        "comercial",
                        "Estado comercial");
        TextField q = new TextField();
        q.setPromptText("Buscar por título o localidad");
        CheckBox mine = new CheckBox("Creadas por mí");
        Runnable filter =
                () ->
                        t.setItems(
                                FXCollections.observableArrayList(
                                        all.stream()
                                                .filter(
                                                        r ->
                                                                (r.text("titulo")
                                                                                + r.text(
                                                                                        "localidad"))
                                                                        .toLowerCase(Locale.ROOT)
                                                                        .contains(
                                                                                q.getText()
                                                                                        .toLowerCase(
                                                                                                Locale
                                                                                                        .ROOT)))
                                                .filter(
                                                        r ->
                                                                !mine.isSelected()
                                                                        || r.id("id_agente_creador")
                                                                                == service.current()
                                                                                        .id(
                                                                                                "id_usuario"))
                                                .toList()));
        q.textProperty().addListener((o, a, b) -> filter.run());
        mine.setOnAction(e -> filter.run());
        HBox top = row(q, button("+ Nueva propiedad", () -> propertyForm(null)));
        if (service.role() != 3) top.getChildren().add(mine);
        FlowPane actions =
                flow(
                        button("Ver ficha", () -> propertyDetails(selected(t).id("id_propiedad"))),
                        secondary("Editar", () -> propertyForm(selected(t))),
                        secondary(
                                "Enviar a revisión",
                                () -> {
                                    service.submit(selected(t).id("id_propiedad"));
                                    propertyList();
                                }));
        if (service.role() != 3)
            actions.getChildren()
                    .addAll(
                            secondary("Cambiar estado", () -> stateForm(selected(t))),
                            secondary("Registrar cierre", () -> closeForm(selected(t))));
        content.getChildren().addAll(top, card(t, actions));
    }

    private void propertyForm(Row original) {
        Row p = original == null ? new Row() : original;
        boolean edit = original != null;
        page(
                edit ? "Editar propiedad #" + p.id("id_propiedad") : "Nueva propiedad",
                "Guardá la ficha en borrador para adjuntar archivos, o enviala a revisión. Las"
                        + " modificaciones requieren una nueva aprobación.");
        Form f = new Form();
        f.text("titulo", "Título *", p.text("titulo"));
        f.rows(
                "id_tipo_propiedad",
                "Tipo de propiedad *",
                service.lookup("tipos_propiedad"),
                p.id("id_tipo_propiedad"),
                false);
        f.text("direccion", "Dirección *", p.text("direccion"));
        f.text("localidad", "Localidad *", p.text("localidad"));
        if (service.role() != 3)
            f.rows(
                    "id_propietario",
                    "Propietario *",
                    service.clients(),
                    p.id("id_propietario"),
                    false);
        f.rows(
                "id_edificio",
                "Edificio / complejo",
                service.lookup("edificios"),
                p.id("id_edificio"),
                true);
        f.text("numero_unidad", "Número de unidad (si hay edificio)", p.text("numero_unidad"));
        f.text("piso", "Piso", p.text("piso"));
        f.text("departamento_numero", "Departamento", p.text("departamento_numero"));
        String[][] numbers = {
            {"superficie_total_m2", "Superficie total m² *", ""},
            {"superficie_cubierta_m2", "Superficie cubierta m²", "0"},
            {"ambientes", "Ambientes", "0"},
            {"dormitorios", "Dormitorios", "0"},
            {"banos", "Baños", "0"},
            {"antiguedad_anos", "Antigüedad (años)", "0"},
            {"capacidad", "Capacidad (personas)", "1"},
            {"expensas", "Expensas (ARS)", "0"}
        };
        for (String[] n : numbers) f.text(n[0], n[1], edit ? p.text(n[0]) : n[2]);
        f.check("apto_profesional", "Apto profesional", p.flag("apto_profesional"));
        f.area("descripcion", "Descripción *", p.text("descripcion"));
        Set<Integer> chosen = new HashSet<>();
        if (edit) service.features(p.id("id_propiedad")).forEach(r -> chosen.add(r.id("id")));
        Map<Integer, CheckBox> features = featureChecks(chosen);
        VBox offersBox =
                card(
                        label("Operaciones y precios", "section-title"),
                        label(
                                "Activá venta, alquiler o ambas. Cada oferta tiene su propio precio"
                                        + " y moneda.",
                                "subtitle"));
        Map<Integer, CheckBox> enabled = new LinkedHashMap<>();
        Map<Integer, TextField> prices = new HashMap<>();
        Map<Integer, ComboBox<String>> currencies = new HashMap<>();
        List<Row> existing = edit ? service.offers(p.id("id_propiedad")) : List.of();
        for (Row type : service.lookup("tipos_transaccion")) {
            int id = type.id("id");
            Row offer =
                    existing.stream()
                            .filter(o -> o.id("id_tipo_transaccion") == id)
                            .findFirst()
                            .orElse(new Row());
            CheckBox on = new CheckBox(type.text("etiqueta"));
            on.setPrefWidth(150);
            on.setSelected(!offer.isEmpty());
            TextField price = new TextField(offer.text("precio"));
            price.setPromptText("Precio");
            price.setPrefWidth(180);
            ComboBox<String> currency =
                    new ComboBox<>(FXCollections.observableArrayList("USD", "ARS"));
            currency.setValue(offer.isEmpty() ? "USD" : offer.text("moneda"));
            enabled.put(id, on);
            prices.put(id, price);
            currencies.put(id, currency);
            offersBox.getChildren().add(row(on, price, currency));
        }
        Consumer<Boolean> save =
                submit -> {
                    List<AgencyService.Offer> offers = new ArrayList<>();
                    enabled.forEach(
                            (id, c) -> {
                                if (c.isSelected())
                                    offers.add(
                                            new AgencyService.Offer(
                                                    id,
                                                    money(prices.get(id).getText()),
                                                    currencies.get(id).getValue()));
                            });
                    int id =
                            service.saveProperty(
                                    edit ? p.id("id_propiedad") : null,
                                    f.values(),
                                    offers,
                                    checked(features),
                                    submit);
                    propertyDetails(id);
                };
        content.getChildren()
                .addAll(
                        card(f),
                        offersBox,
                        card(
                                label("Características adicionales", "section-title"),
                                flow(features.values().toArray(Node[]::new))),
                        flow(
                                secondary("Guardar borrador", () -> save.accept(false)),
                                button("Guardar y enviar a revisión", () -> save.accept(true)),
                                secondary("Cancelar", this::propertyList)));
    }

    private void stateForm(Row p) {
        Form f = new Form();
        f.rows(
                "estado",
                "Nuevo estado",
                service.lookup("estados_comerciales").stream()
                        .filter(r -> Set.of(1, 2, 5, 6).contains(r.id("id")))
                        .toList(),
                p.id("id_estado_comercial"),
                false);
        f.area("motivo", "Motivo del cambio", "");
        dialog(
                "Estado de " + p.text("titulo"),
                card(
                        f,
                        label(
                                "Al reactivar una propiedad cerrada o fuera de mercado, vuelve a"
                                        + " borrador y requiere aprobación.",
                                "subtitle")),
                "Guardar cambio",
                () -> {
                    service.changeState(
                            p.id("id_propiedad"), number(f.value("estado")), f.value("motivo"));
                    propertyList();
                });
    }

    private void closeForm(Row p) {
        Form f = new Form();
        f.rows("client", "Cliente comprador / inquilino", service.clients(), 0, false);
        List<Row> offers = new ArrayList<>();
        for (Row o : service.offers(p.id("id_propiedad"))) {
            Row r = new Row();
            r.put("id", o.id("id_tipo_transaccion"));
            r.put("etiqueta", o.text("operacion") + " · " + o.text("moneda"));
            r.put("precio", o.get("precio"));
            offers.add(r);
        }
        ComboBox<Row> operation = f.rows("operation", "Operación / moneda", offers, 0, false);
        TextField finalPrice =
                f.text(
                        "price",
                        "Precio final (moneda de la oferta)",
                        operation.getValue() == null ? "" : operation.getValue().text("precio"));
        operation
                .valueProperty()
                .addListener(
                        (observable, before, after) -> {
                            if (after != null) finalPrice.setText(after.text("precio"));
                        });
        f.text("commission", "Comisión total (misma moneda)", "0");
        dialog(
                "Registrar cierre",
                f,
                "Confirmar cierre",
                () -> {
                    service.close(
                            p.id("id_propiedad"),
                            number(f.value("client")),
                            number(f.value("operation")),
                            money(f.value("price")),
                            money(f.value("commission")));
                    operations();
                });
    }

    private void requests() {
        page(
                "Solicitudes de publicación",
                "Seguí cada envío y su revisión. Los rechazos incluyen el motivo para corregir la"
                        + " ficha.");
        TableView<Row> t =
                table(
                        service.requests(),
                        "id_publicacion",
                        "ID",
                        "titulo",
                        "Propiedad",
                        "solicitante",
                        "Solicitante",
                        "estado",
                        "Estado",
                        "observaciones",
                        "Observaciones",
                        "fecha_solicitud",
                        "Enviada");
        FlowPane actions =
                flow(
                        button(
                                "Ver propiedad",
                                () -> propertyDetails(selected(t).id("id_propiedad"))));
        if (service.role() == 1) {
            actions.getChildren()
                    .addAll(
                            secondary("Aprobar", () -> reviewForm(selected(t), true)),
                            secondary("Rechazar", () -> reviewForm(selected(t), false)));
        }
        content.getChildren().add(card(t, actions));
    }

    private void reviewForm(Row r, boolean approve) {
        Form f = new Form();
        f.area("observaciones", approve ? "Observaciones (opcional)" : "Motivo del rechazo *", "");
        dialog(
                (approve ? "Aprobar" : "Rechazar") + " solicitud #" + r.id("id_publicacion"),
                f,
                "Confirmar",
                () -> {
                    service.review(r.id("id_publicacion"), approve, f.value("observaciones"));
                    requests();
                });
    }

    private void clients() {
        page("Clientes", "Ficha única, roles comerciales e historial compartido de atención.");
        TableView<Row> t =
                table(
                        service.clients(),
                        "id",
                        "ID",
                        "etiqueta",
                        "Cliente",
                        "dni",
                        "Documento",
                        "email",
                        "Correo",
                        "telefono",
                        "Teléfono",
                        "fecha_inicio_relacion",
                        "Inicio relación");
        content.getChildren()
                .addAll(
                        button("+ Registrar cliente", () -> newUser(false)),
                        card(
                                t,
                                flow(
                                        button("Ver ficha", () -> clientDetails(selected(t))),
                                        secondary(
                                                "Registrar contacto",
                                                () -> contactForm(selected(t).id("id"))),
                                        secondary(
                                                "Perfil de búsqueda",
                                                () -> preferences(selected(t).id("id"))),
                                        secondary(
                                                "Intereses",
                                                () -> interests(selected(t).id("id"))))));
    }

    private void newUser(boolean admin) {
        Form f = userForm();
        PasswordField pass = f.password("password", "Contraseña inicial (mínimo 10 caracteres)");
        if (admin)
            f.choice("role", "Rol de acceso", "Cliente", "Cliente", "Agente", "Administrador");
        dialog(
                admin ? "Crear usuario" : "Registrar cliente",
                card(
                        f,
                        label(
                                "El correo y el documento deben ser únicos. El cliente podrá"
                                        + " cambiar su contraseña desde Mi perfil.",
                                "subtitle")),
                "Crear",
                () -> {
                    if (admin) {
                        int role =
                                switch (f.value("role")) {
                                    case "Administrador" -> 1;
                                    case "Agente" -> 2;
                                    default -> 3;
                                };
                        service.createStaffUser(f.values(), pass.getText(), role);
                        users();
                    } else {
                        service.registerClient(f.values(), pass.getText());
                        clients();
                    }
                });
    }

    private void clientDetails(Row client) {
        int id = client.id("id");
        page(
                client.text("etiqueta"),
                client.text("email")
                        + " · "
                        + client.text("telefono")
                        + " · Documento "
                        + client.text("dni"));
        Set<String> roles = new HashSet<>();
        service.clientRoles(id).forEach(r -> roles.add(r.text("tipo_rol")));
        Map<String, CheckBox> checks = new LinkedHashMap<>();
        for (String role :
                List.of("Comprador", "Vendedor", "Propietario", "Inquilino", "Inversor")) {
            CheckBox c = new CheckBox(role);
            c.setSelected(roles.contains(role));
            checks.put(role, c);
        }
        Form assign = new Form();
        assign.rows(
                "agent",
                "Agente asignado",
                service.agents(),
                client.id("id_agente_asignado"),
                true);
        content.getChildren()
                .add(
                        card(
                                label("Roles del cliente", "section-title"),
                                flow(checks.values().toArray(Node[]::new)),
                                assign,
                                button(
                                        "Guardar ficha",
                                        () -> {
                                            Set<String> chosen = new HashSet<>();
                                            checks.forEach(
                                                    (k, c) -> {
                                                        if (c.isSelected()) chosen.add(k);
                                                    });
                                            int agent = number(assign.value("agent"));
                                            service.saveClient(
                                                    id, chosen, agent == 0 ? null : agent);
                                            info("Ficha actualizada.");
                                        })));
        content.getChildren()
                .add(
                        card(
                                label("Historial de atención", "section-title"),
                                table(
                                        service.contacts(id),
                                        "fecha",
                                        "Fecha",
                                        "agente",
                                        "Agente",
                                        "tipo",
                                        "Tipo",
                                        "descripcion",
                                        "Descripción",
                                        "resultado",
                                        "Resultado"),
                                button("Registrar contacto", () -> contactForm(id))));
        content.getChildren()
                .add(
                        flow(
                                button("Ver intereses", () -> interests(id)),
                                secondary("Perfil de búsqueda", () -> preferences(id))));
    }

    private void contactForm(int client) {
        Form f = new Form();
        f.choice("tipo", "Tipo de contacto", "Llamada", "Llamada", "Mensaje", "Visita", "Reunión");
        f.rows("property", "Propiedad (opcional)", propertyOptions(), 0, true);
        f.area("descripcion", "Descripción *", "");
        f.area("resultado", "Resultado / próximos pasos", "");
        dialog(
                "Registrar contacto",
                f,
                "Guardar contacto",
                () -> {
                    int p = number(f.value("property"));
                    service.contact(
                            client,
                            p == 0 ? null : p,
                            f.value("tipo"),
                            f.value("descripcion"),
                            f.value("resultado"));
                    clients();
                });
    }

    private List<Row> propertyOptions() {
        List<Row> out = new ArrayList<>();
        List<Row> props =
                service.role() == 3
                        ? service.properties(true, "", null, null, null, "USD", 0, 0, Set.of())
                        : service.allProperties();
        for (Row p : props) {
            Row r = new Row();
            r.put("id", p.id("id_propiedad"));
            r.put("etiqueta", "#" + p.id("id_propiedad") + " · " + p.text("titulo"));
            out.add(r);
        }
        return out;
    }

    private void interests(int client) {
        page(
                "Intereses y seguimiento",
                "Registrá las propiedades de interés y los avances de cada gestión.");
        TableView<Row> t =
                table(
                        service.interests(client),
                        "id_propiedad",
                        "Propiedad ID",
                        "titulo",
                        "Propiedad",
                        "estado",
                        "Estado",
                        "acciones",
                        "Seguimiento",
                        "fecha",
                        "Fecha");
        content.getChildren()
                .add(
                        card(
                                t,
                                flow(
                                        button(
                                                "+ Vincular propiedad",
                                                () -> interestForm(client, null)),
                                        secondary(
                                                "Actualizar seguimiento",
                                                () -> interestForm(client, selected(t))),
                                        secondary(
                                                "Ver propiedad",
                                                () ->
                                                        propertyDetails(
                                                                selected(t).id("id_propiedad"))))));
    }

    private void interestForm(int client, Row existing) {
        Form f = new Form();
        if (existing == null) f.rows("property", "Propiedad", propertyOptions(), 0, false);
        f.choice(
                "estado",
                "Estado",
                existing == null ? "Interesado" : existing.text("estado"),
                "Interesado",
                "Contactado",
                "Visita coordinada",
                "Negociación",
                "Descartado");
        f.area(
                "acciones",
                "Acciones y próximos pasos",
                existing == null ? "" : existing.text("acciones"));
        dialog(
                "Seguimiento del interés",
                f,
                "Guardar",
                () -> {
                    service.interest(
                            client,
                            existing == null
                                    ? number(f.value("property"))
                                    : existing.id("id_propiedad"),
                            f.value("estado"),
                            f.value("acciones"));
                    interests(client);
                });
    }

    private void preferences(int client) {
        Row p = service.preference(client);
        page(
                "Perfil de búsqueda",
                "Guardá las preferencias del cliente y encontrá propiedades compatibles.");
        Form f = new Form();
        f.rows(
                "id_tipo_transaccion",
                "Operación",
                service.lookup("tipos_transaccion"),
                p.id("id_tipo_transaccion"),
                false);
        f.rows(
                "id_tipo_propiedad",
                "Tipo de propiedad",
                service.lookup("tipos_propiedad"),
                p.id("id_tipo_propiedad"),
                true);
        f.text("presupuesto_maximo", "Presupuesto máximo *", p.text("presupuesto_maximo"));
        f.choice("moneda", "Moneda", p.text("moneda"), "USD", "ARS");
        f.text("zona_interes", "Localidad o zona de interés", p.text("zona_interes"));
        f.text(
                "ambientes_minimos",
                "Ambientes mínimos",
                p.isEmpty() ? "0" : p.text("ambientes_minimos"));
        f.text(
                "dormitorios_minimos",
                "Dormitorios mínimos",
                p.isEmpty() ? "0" : p.text("dormitorios_minimos"));
        f.text(
                "superficie_minima_m2",
                "Superficie mínima m²",
                p.isEmpty() ? "0" : p.text("superficie_minima_m2"));
        f.date(
                "fecha_estimada_concretar",
                "Fecha estimada de operación",
                p.text("fecha_estimada_concretar"));
        f.check("requiere_venta_previa", "Necesita vender antes", p.flag("requiere_venta_previa"));
        Set<Integer> chosen = new HashSet<>();
        service.preferenceFeatures(client).forEach(r -> chosen.add(r.id("id")));
        Map<Integer, CheckBox> features = featureChecks(chosen);
        content.getChildren()
                .add(
                        card(
                                f,
                                label("Características deseadas", "section-title"),
                                flow(features.values().toArray(Node[]::new)),
                                button(
                                        "Guardar y buscar coincidencias",
                                        () -> {
                                            service.savePreference(
                                                    client, f.values(), checked(features));
                                            preferences(client);
                                        })));
        if (!p.isEmpty()) {
            FlowPane matches = new FlowPane(18, 18);
            List<Row> results = service.matches(client);
            results.forEach(r -> matches.getChildren().add(propertyCard(r)));
            content.getChildren()
                    .addAll(
                            label(results.size() + " propiedades compatibles", "section-title"),
                            matches);
        }
    }

    private void agreements() {
        page(
                "Propietarios y convenios",
                "Condiciones acordadas con propietarios y otros profesionales inmobiliarios.");
        content.getChildren()
                .addAll(
                        button(
                                "+ Registrar convenio",
                                () -> {
                                    Form f = new Form();
                                    f.rows("owner", "Propietario", service.clients(), 0, false);
                                    f.rows(
                                            "property",
                                            "Propiedad (opcional)",
                                            propertyOptions(),
                                            0,
                                            true);
                                    f.text(
                                            "professional",
                                            "Profesional / inmobiliaria colaboradora",
                                            "");
                                    f.date("date", "Fecha", LocalDate.now().toString());
                                    f.area("conditions", "Condiciones *", "");
                                    dialog(
                                            "Nuevo convenio",
                                            f,
                                            "Guardar",
                                            () -> {
                                                int p = number(f.value("property"));
                                                service.agreement(
                                                        number(f.value("owner")),
                                                        p == 0 ? null : p,
                                                        f.value("professional"),
                                                        f.value("conditions"),
                                                        LocalDate.parse(f.value("date")));
                                                agreements();
                                            });
                                }),
                        card(
                                table(
                                        service.agreements(),
                                        "id_convenio",
                                        "ID",
                                        "propietario",
                                        "Propietario",
                                        "id_propiedad",
                                        "Propiedad ID",
                                        "profesional",
                                        "Profesional",
                                        "condiciones",
                                        "Condiciones",
                                        "fecha",
                                        "Fecha")));
    }

    private void buildings() {
        page(
                "Edificios y unidades",
                "Cada unidad es una propiedad independiente vinculada a su edificio.");
        TableView<Row> t =
                table(
                        service.buildings(),
                        "id_edificio",
                        "ID",
                        "nombre",
                        "Edificio",
                        "direccion",
                        "Dirección",
                        "localidad",
                        "Localidad",
                        "unidades",
                        "Unidades");
        content.getChildren()
                .addAll(
                        button(
                                "+ Nuevo edificio",
                                () -> {
                                    Form f = new Form();
                                    f.text("name", "Nombre *", "");
                                    f.text("address", "Dirección *", "");
                                    f.text("city", "Localidad *", "");
                                    dialog(
                                            "Crear edificio",
                                            f,
                                            "Guardar",
                                            () -> {
                                                service.building(
                                                        f.value("name"),
                                                        f.value("address"),
                                                        f.value("city"));
                                                buildings();
                                            });
                                }),
                        card(
                                t,
                                secondary(
                                        "Ver unidades",
                                        () -> {
                                            Row e = selected(t);
                                            page(
                                                    "Unidades · " + e.text("nombre"),
                                                    e.text("direccion"));
                                            TableView<Row> units =
                                                    table(
                                                            service.allProperties().stream()
                                                                    .filter(
                                                                            p ->
                                                                                    p.id(
                                                                                                    "id_edificio")
                                                                                            == e.id(
                                                                                                    "id_edificio"))
                                                                    .toList(),
                                                            "id_propiedad",
                                                            "ID",
                                                            "numero_unidad",
                                                            "Unidad",
                                                            "titulo",
                                                            "Propiedad",
                                                            "comercial",
                                                            "Estado");
                                            content.getChildren()
                                                    .add(
                                                            card(
                                                                    units,
                                                                    button(
                                                                            "Ver ficha",
                                                                            () ->
                                                                                    propertyDetails(
                                                                                            selected(
                                                                                                            units)
                                                                                                    .id(
                                                                                                            "id_propiedad")))));
                                        })));
    }

    private void operations() {
        page(
                "Ventas y alquileres",
                "Historial de cierres. Una propiedad puede volver al mercado sin perder operaciones"
                        + " anteriores.");
        List<Row> ops = service.operations();
        content.getChildren()
                .add(
                        card(
                                table(
                                        ops,
                                        "id_operacion",
                                        "ID",
                                        "titulo",
                                        "Propiedad",
                                        "cliente",
                                        "Cliente",
                                        "operacion",
                                        "Operación",
                                        "precio_final",
                                        "Importe",
                                        "moneda",
                                        "Moneda",
                                        "comision_total",
                                        "Comisión",
                                        "fecha_cierre",
                                        "Fecha"),
                                button("Exportar CSV", () -> export(ops, "operaciones.csv"))));
    }

    private void notifications() {
        page("Notificaciones", "Novedades sobre tus solicitudes y operaciones.");
        TableView<Row> t =
                table(
                        service.notifications(),
                        "fecha",
                        "Fecha",
                        "mensaje",
                        "Mensaje",
                        "leida",
                        "Leída (1 = sí)");
        content.getChildren()
                .add(
                        card(
                                t,
                                button(
                                        "Marcar como leída",
                                        () -> {
                                            service.readNotification(
                                                    selected(t).id("id_notificacion"));
                                            notifications();
                                        })));
    }

    private void users() {
        page("Usuarios", "Creá cuentas para el equipo y administrá su acceso al sistema.");
        TableView<Row> t =
                table(
                        service.users(),
                        "id",
                        "ID",
                        "etiqueta",
                        "Nombre",
                        "email",
                        "Correo",
                        "rol",
                        "Rol",
                        "activo",
                        "Activo (1 = sí)");
        content.getChildren()
                .addAll(
                        button("+ Crear usuario", () -> newUser(true)),
                        card(
                                t,
                                flow(
                                        secondary(
                                                "Activar",
                                                () -> {
                                                    service.setActive(selected(t).id("id"), true);
                                                    users();
                                                }),
                                        secondary(
                                                "Desactivar",
                                                () -> {
                                                    Row u = selected(t);
                                                    Alert a =
                                                            new Alert(
                                                                    Alert.AlertType.CONFIRMATION,
                                                                    "¿Desactivar el acceso de "
                                                                            + u.text("etiqueta")
                                                                            + "?",
                                                                    ButtonType.YES,
                                                                    ButtonType.NO);
                                                    a.initOwner(stage);
                                                    a.setHeaderText(null);
                                                    if (a.showAndWait().orElse(ButtonType.NO)
                                                            == ButtonType.YES) {
                                                        service.setActive(u.id("id"), false);
                                                        users();
                                                    }
                                                }))));
    }

    private void profile() {
        Row u = service.current();
        page("Mi perfil", u.text("email") + " · Documento " + u.text("dni"));
        Form f = new Form();
        for (String k : List.of("nombre", "apellido", "telefono", "direccion", "localidad"))
            f.text(k, k.substring(0, 1).toUpperCase() + k.substring(1), u.text(k));
        content.getChildren()
                .add(
                        card(
                                f,
                                button(
                                        "Guardar perfil",
                                        () -> {
                                            service.updateProfile(f.values());
                                            shell();
                                            profile();
                                        })));
        Form pw = new Form();
        PasswordField old = pw.password("old", "Contraseña actual");
        PasswordField next = pw.password("next", "Contraseña nueva (mínimo 10 caracteres)");
        content.getChildren()
                .add(
                        card(
                                label("Cambiar contraseña", "section-title"),
                                pw,
                                button(
                                        "Actualizar contraseña",
                                        () -> {
                                            service.changePassword(old.getText(), next.getText());
                                            old.clear();
                                            next.clear();
                                            info("Contraseña actualizada.");
                                        })));
    }

    private void settings() {
        page("Configuración", "Información de esta instalación de escritorio.");
        content.getChildren()
                .add(
                        card(
                                label(
                                        service.db.demo
                                                ? "Modo demostración · H2 local"
                                                : "Conexión MySQL / MariaDB",
                                        "section-title"),
                                label(
                                        "Archivos: "
                                                + service.db.storage
                                                + "\n"
                                                + "La conexión se configura en config.properties,"
                                                + " junto al pom.xml. Reiniciá la aplicación"
                                                + " después de modificarla.",
                                        "subtitle"),
                                secondary("Editar mi perfil y contraseña", this::profile)));
    }

    private void reports() {
        page("Reportes", "Métricas calculadas a partir de los registros del sistema.");
        List<Row> props = service.allProperties(), ops = service.operations();
        content.getChildren()
                .add(
                        flow(
                                stat("Clientes", service.clients().size()),
                                stat("Propiedades", props.size()),
                                stat(
                                        "Ventas cerradas",
                                        ops.stream()
                                                .filter(r -> r.id("id_tipo_transaccion") == 1)
                                                .count()),
                                stat(
                                        "Alquileres registrados",
                                        ops.stream()
                                                .filter(r -> r.id("id_tipo_transaccion") != 1)
                                                .count())));
        for (String currency : List.of("USD", "ARS")) {
            BigDecimal total =
                    ops.stream()
                            .filter(r -> r.text("moneda").equals(currency))
                            .map(r -> r.money("precio_final"))
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
            BigDecimal commissions =
                    ops.stream()
                            .filter(r -> r.text("moneda").equals(currency))
                            .map(r -> r.money("comision_total"))
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
            content.getChildren()
                    .add(
                            card(
                                    label("Totales en " + currency, "section-title"),
                                    label(
                                            "Operaciones: "
                                                    + total
                                                    + " · Comisiones: "
                                                    + commissions,
                                            "price")));
        }
        List<Row> activity = service.activity();
        content.getChildren()
                .add(
                        card(
                                label("Auditoría · últimos 200 eventos", "section-title"),
                                table(
                                        activity,
                                        "fecha",
                                        "Fecha",
                                        "usuario",
                                        "Usuario",
                                        "accion",
                                        "Acción",
                                        "entidad",
                                        "Entidad",
                                        "id_registro",
                                        "Registro",
                                        "detalle",
                                        "Detalle"),
                                button(
                                        "Exportar auditoría CSV",
                                        () -> export(activity, "auditoria.csv"))));
    }

    private void export(List<Row> rows, String filename) {
        if (rows.isEmpty()) throw new IllegalArgumentException("No hay datos para exportar.");
        FileChooser chooser = new FileChooser();
        chooser.setInitialFileName(filename);
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV", "*.csv"));
        java.io.File file = chooser.showSaveDialog(stage);
        if (file == null) return;
        List<String> keys = new ArrayList<>(rows.getFirst().keySet());
        StringBuilder csv = new StringBuilder("\uFEFF");
        csv.append(String.join(";", keys)).append("\r\n");
        for (Row r : rows) {
            List<String> cells = new ArrayList<>();
            for (String key : keys) {
                String v = r.text(key);
                if (v.matches("^[=+@\\-].*")) v = "'" + v;
                cells.add("\"" + v.replace("\"", "\"\"") + "\"");
            }
            csv.append(String.join(";", cells)).append("\r\n");
        }
        try {
            Files.writeString(file.toPath(), csv);
        } catch (Exception e) {
            throw new IllegalArgumentException("No se pudo guardar el CSV", e);
        }
        info("Reporte exportado en " + file);
    }
}
